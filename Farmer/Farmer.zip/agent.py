import queue
import random
from typing import List, Tuple, Callable
from game.board import Board
from game.enums import Direction, MoveType, loc_after_direction
from .oracle import Oracle

class PlayerAgent:
    def __init__(self, board: Board, time_left: Callable):
        self.map_size = board.game_map.MAP_SIZE
        self.oracle = Oracle(self.map_size)
        self.turn_number = 0
        self.my_parity = board.chicken_player.even_chicken
        
        # 1. Generate the "Lawnmower" Tour
        # This creates a fixed list of targets in a snake pattern.
        # Col 0 (Down) -> Col 1 (Up) -> Col 2 (Down) ...
        self.tour_targets = []
        for col in range(self.map_size):
            if col % 2 == 0:
                # Even Cols: Go Down (0 -> 7)
                rows = range(self.map_size)
            else:
                # Odd Cols: Go Up (7 -> 0)
                rows = range(self.map_size - 1, -1, -1)
                
            for row in rows:
                if (row + col) % 2 == self.my_parity:
                    self.tour_targets.append((row, col))

        self.target_index = 0
        self.path_to_target = []
        self.visit_counts = {}

    def play(self, board: Board, sensor_data: List[Tuple[bool, bool]], time_left: Callable):
        self.turn_number += 1
        my_loc = board.chicken_player.get_location()
        self.oracle.update(my_loc, sensor_data)
        self.visit_counts[my_loc] = self.visit_counts.get(my_loc, 0) + 1

        # 1. HARVEST: If I'm on a valid empty square, EGG IT.
        # Don't think, just score.
        if self._can_score_here(board, my_loc):
            # Find valid exit
            for d in [Direction.UP, Direction.DOWN, Direction.LEFT, Direction.RIGHT]:
                if board.is_valid_move(d, MoveType.EGG):
                    return (d, MoveType.EGG)

        # 2. LAWNMOWER TARGETING
        # Find the first target in our list that is not yet done
        target = self._get_next_tour_target(board, my_loc)
        
        # 3. NAVIGATION
        if target:
            # Re-plan if needed
            if not self.path_to_target or self.path_to_target[0] != my_loc:
                self.path_to_target = self._astar_path(board, my_loc, target)
            
            # Execute path
            if self.path_to_target and len(self.path_to_target) > 1:
                next_step = self.path_to_target[1]
                d = self._get_direction(my_loc, next_step)
                
                # HARVEST EN ROUTE:
                # If we can lay an egg while moving in the right direction, DO IT.
                if board.can_lay_egg() and board.is_valid_move(d, MoveType.EGG):
                    return (d, MoveType.EGG)
                    
                if board.is_valid_move(d, MoveType.PLAIN):
                    self.path_to_target.pop(0) # Advance path
                    return (d, MoveType.PLAIN)
                else:
                    # Path blocked? Force re-calc next turn
                    self.path_to_target = []

        # 4. FALLBACK (Stuck?)
        # If Lawnmower fails (blocked path), move randomly to safe square
        return self._get_survival_move(board, my_loc)

    def _get_next_tour_target(self, board, my_loc):
        """
        Scans the pre-calculated tour list.
        Returns the first square that is:
        1. Empty (no egg/turd)
        2. Safe (Risk < 20%)
        3. Reachable (implicitly checked by A* later)
        """
        # Find where we are in the list roughly, to prioritize nearby
        # Actually, just scan the whole list. We want to fill holes we missed.
        
        best_target = None
        min_dist = 999
        
        # Optimization: Look for the closest target in our tour list that needs filling.
        # This keeps us "on the line" but allows us to skip ahead if blocked.
        for t in self.tour_targets:
            # Skip if done
            if t in board.eggs_player: continue
            if t in board.turds_player: continue
            if t in board.turds_enemy: continue
            if board.is_cell_in_enemy_turd_zone(t): continue
            
            # Skip if unsafe
            if self.oracle.get_risk(t) > 0.20: continue
            
            # Pick the closest valid one
            dist = abs(t[0] - my_loc[0]) + abs(t[1] - my_loc[1])
            if dist < min_dist:
                min_dist = dist
                best_target = t
                
                # Optimization: If it's very close, just take it. 
                # Don't search the whole board.
                if dist <= 3: 
                    return t
                    
        return best_target

    def _astar_path(self, board, start, goal):
        frontier = queue.PriorityQueue()
        frontier.put((0, start))
        came_from = {start: None}
        cost_so_far = {start: 0}
        
        while not frontier.empty():
            _, current = frontier.get()
            if current == goal: break
            
            for d in [Direction.UP, Direction.DOWN, Direction.LEFT, Direction.RIGHT]:
                next_loc = loc_after_direction(current, d)
                
                if not (0 <= next_loc[0] < self.map_size and 0 <= next_loc[1] < self.map_size): continue
                if board.is_cell_blocked(next_loc): continue
                if self.oracle.get_risk(next_loc) > 0.20: continue
                
                # Anti-Wiggle: Penalize revisited squares
                visits = self.visit_counts.get(next_loc, 0)
                step_cost = 1 + (visits * 50) # High friction for old paths
                
                new_cost = cost_so_far[current] + step_cost
                if next_loc not in cost_so_far or new_cost < cost_so_far[next_loc]:
                    cost_so_far[next_loc] = new_cost
                    priority = new_cost + self._heuristic(next_loc, goal)
                    frontier.put((priority, next_loc))
                    came_from[next_loc] = current
                    
        if goal not in came_from: return None
        
        path = []
        curr = goal
        while curr != start:
            path.append(curr)
            curr = came_from[curr]
        path.reverse()
        path.insert(0, start)
        return path

    def _get_survival_move(self, board, my_loc):
        valid_moves = board.get_valid_moves()
        random.shuffle(valid_moves)
        best_move = (Direction.UP, MoveType.PLAIN)
        min_visits = float('inf')
        
        # Pick safest, least-visited neighbor
        for move in valid_moves:
            if move[1] == MoveType.PLAIN:
                next_pos = loc_after_direction(my_loc, move[0])
                if self.oracle.get_risk(next_pos) > 0.50: continue # Don't suicide
                
                visits = self.visit_counts.get(next_pos, 0)
                if visits < min_visits:
                    min_visits = visits
                    best_move = move
        return best_move

    def _can_score_here(self, board, loc):
        if (loc[0] + loc[1]) % 2 != self.my_parity: return False
        if loc in board.eggs_player: return False
        if loc in board.turds_player: return False
        if loc in board.turds_enemy: return False
        if loc in board.eggs_enemy: return False
        return True

    def _get_direction(self, start, end):
        dx = end[0] - start[0]
        dy = end[1] - start[1]
        if dx == 1: return Direction.RIGHT
        if dx == -1: return Direction.LEFT
        if dy == 1: return Direction.DOWN
        return Direction.UP

    def _heuristic(self, a, b):
        return abs(a[0] - b[0]) + abs(a[1] - b[1])