import os
import torch
import numpy as np
import time
from game.enums import Direction, MoveType
from .model import ZeroNet
from .neuro_mcts import NeuroMCTS, decode_move_idx, encode_move_idx
from .belief import TrapdoorBelief

class PlayerAgent:
    def __init__(self, board, time_left):
        # 1. FORCE CPU MODE (Matches Tournament Environment)
        self.device = torch.device("cpu")
        # print(f"NEURO: Configured for {self.device}")
        
        self.net = ZeroNet().to(self.device)
        self.brain_ready = False
        self.belief = TrapdoorBelief()
        self.location_history = [] 
        
        path = os.path.join(os.path.dirname(__file__), "brain.pth")
        if os.path.exists(path):
            try:
                state = torch.load(path, map_location=self.device, weights_only=False)
                self.net.load_state_dict(state)
                self.net.eval()
                self.mcts = NeuroMCTS(self.net)
                self.brain_ready = True
            except Exception as e:
                print(f"NEURO: Load failed! {e}")
        
    def play(self, board, sensor_data, time_left):
        try:
            valid_moves = board.get_valid_moves()
            if not valid_moves: return (Direction.UP, MoveType.PLAIN)

            # 1. Beliefs
            my_loc = board.chicken_player.get_location()
            self.belief.update(my_loc, sensor_data)
            if hasattr(board, 'found_trapdoors'):
                self.belief.set_confirmed_traps(board.found_trapdoors)
            
            if not self.brain_ready:
                return valid_moves[0]
            
            # 2. Time Management (CPU Optimized)
            turns_remaining = board.turns_left_player
            my_time = time_left()
            
            # Bigger safety buffer for CPU jitter
            usable_time = my_time - 2.0
            
            if usable_time <= 0.5:
                thinking_time = 0.0
            else:
                # More conservative budget
                base_budget = usable_time / (turns_remaining + 2)
                thinking_time = min(base_budget, 2.0)
                
            start_t = time.time()
            root = self.mcts.search_setup(board, belief_map=self.belief.probs)
            
            # 3. Run Simulations (Batch Size 1 is faster on CPU due to less overhead)
            sims = 0
            if thinking_time > 0.05:
                while time.time() - start_t < thinking_time:
                    self.mcts.search_batch(root, batch_size=1)
                    sims += 1
                    # Check budget every 10 sims to reduce system call overhead
                    if sims % 10 == 0 and (time.time() - start_t) > thinking_time:
                        break
            
            probs = self.mcts.get_probs(root)
            
            # 4. Loop Prevention & Selection
            best_move = valid_moves[0]
            best_score = -999.0
            
            for d, t in valid_moves:
                idx = encode_move_idx(d, t)
                move_prob = probs[idx]
                
                dx, dy = 0, 0
                if d == Direction.UP: dy = -1
                elif d == Direction.DOWN: dy = 1
                elif d == Direction.LEFT: dx = -1
                elif d == Direction.RIGHT: dx = 1
                
                target_r = my_loc[0] + dy
                target_c = my_loc[1] + dx
                target_loc = (target_r, target_c)
                
                penalty = 0.0
                if len(self.location_history) >= 1 and target_loc == self.location_history[-1]:
                    penalty = 0.25 
                elif target_loc in self.location_history[-4:]:
                    penalty = 0.1
                
                score = move_prob - penalty
                if score > best_score:
                    best_score = score
                    best_move = (d, t)
            
            self.location_history.append(my_loc)
            if len(self.location_history) > 8: 
                self.location_history.pop(0)
            
            return best_move

        except Exception as e:
            print(f"NEURO CRASHED: {e}")
            valid_moves = board.get_valid_moves()
            return valid_moves[0] if valid_moves else (Direction.UP, MoveType.PLAIN)