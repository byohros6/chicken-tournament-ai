import os
import torch
import numpy as np
import time
from game.enums import Direction, MoveType
# Added encode_move_idx to imports
from .model import ZeroNet
from .neuro_mcts import NeuroMCTS, decode_move_idx, encode_move_idx
from .belief import TrapdoorBelief

class PlayerAgent:
    def __init__(self, board, time_left):
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.net = ZeroNet().to(self.device)
        self.brain_ready = False
        
        self.belief = TrapdoorBelief()
        
        path = os.path.join(os.path.dirname(__file__), "brain.pth")
        if os.path.exists(path):
            try:
                state = torch.load(path, map_location=self.device, weights_only=False)
                self.net.load_state_dict(state)
                self.net.eval()
                dummy = torch.zeros((1, 8, 8, 8), device=self.device)
                self.net(dummy)
                self.mcts = NeuroMCTS(self.net)
                self.brain_ready = True
                print("NEURO: Grandmaster Brain Loaded.")
            except Exception as e:
                print(f"NEURO: Load failed! {e}")
        
    def play(self, board, sensor_data, time_left):
        my_loc = board.chicken_player.get_location()
        self.belief.update(my_loc, sensor_data)
        
        valid_moves = board.get_valid_moves()
        if not valid_moves: return (Direction.UP, MoveType.PLAIN) # Resign

        if not self.brain_ready:
            return valid_moves[0]
            
        # DYNAMIC TIME MANAGEMENT
        turns_remaining = board.turns_left_player
        my_time = time_left()
        
        if my_time < 1.0:
            thinking_time = 0.05
        else:
            # Use slightly more time to prevent blunders
            base_budget = my_time / (turns_remaining + 2)
            thinking_time = min(base_budget * 1.5, 4.0)
            
        start_t = time.time()
        root = self.mcts.search_setup(board, belief_map=self.belief.probs)
        
        # Search until time is up
        while time.time() - start_t < thinking_time:
            self.mcts.search_batch(root, batch_size=32)
            
        probs = self.mcts.get_probs(root)
        
        # --- SAFETY FILTER (THE FIX) ---
        # Instead of just taking argmax(probs), we only look at VALID moves.
        best_move = valid_moves[0]
        best_prob = -1.0
        
        for d, t in valid_moves:
            idx = encode_move_idx(d, t)
            move_prob = probs[idx]
            
            if move_prob > best_prob:
                best_prob = move_prob
                best_move = (d, t)
        
        return best_move