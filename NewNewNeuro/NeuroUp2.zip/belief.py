import numpy as np

def prob_hear(dx, dy):
    if dx > 2 or dy > 2: return 0.0
    if dx == 2 or dy == 2: return 0.1
    if dx == 1 or dy == 1: return 0.25  # Actually rules say 50% adj, 25% diag. 
    # Simplified approximation based on rules:
    # Adj (1,0): Hear 0.5
    # Diag (1,1): Hear 0.25
    # Adj-Adj (2,0): Hear 0.1
    return 0.0 # Fallback

def get_sensor_probs(dx, dy):
    # Exact values from the rules text
    if dx + dy == 1: return 0.5, 0.3   # Adjacent
    if dx == 1 and dy == 1: return 0.25, 0.15 # Diagonal
    if dx + dy == 2: return 0.1, 0.0   # 2-step
    return 0.0, 0.0

class TrapdoorBelief:
    def __init__(self):
        self.probs = np.ones((8, 8)) * 0.02 # Prior
        
        # Apply rule-based priors (Center weighted)
        # Ring 0 (Edge): 0
        # Ring 1: 0
        # Ring 2: 1
        # Ring 3 (Center): 2
        weights = np.zeros((8,8))
        for r in range(8):
            for c in range(8):
                dist_edge = min(r, 7-r, c, 7-c)
                if dist_edge >= 3: w = 2
                elif dist_edge == 2: w = 1
                else: w = 0
                weights[r,c] = w
        
        # Normalize
        self.probs = weights / (np.sum(weights) + 1e-8)

    def update(self, my_loc, sensor_data):
        # sensor_data: [(hear_w, feel_w), (hear_b, feel_b)]
        # 0 = White (Even), 1 = Black (Odd)
        
        for parity in [0, 1]:
            heard, felt = sensor_data[parity]
            
            # Update every square of matching parity
            for r in range(8):
                for c in range(8):
                    if (r+c)%2 != parity: 
                        self.probs[r,c] = 0
                        continue
                        
                    dx, dy = abs(r-my_loc[0]), abs(c-my_loc[1])
                    p_h, p_f = get_sensor_probs(dx, dy)
                    
                    # Likelihood
                    l_hear = p_h if heard else (1 - p_h)
                    l_feel = p_f if felt else (1 - p_f)
                    
                    self.probs[r,c] *= (l_hear * l_feel)
                    
            # Normalize this parity group
            mask = (np.indices((8,8)).sum(axis=0) % 2) == parity
            total = np.sum(self.probs[mask])
            if total > 0:
                self.probs[mask] /= total