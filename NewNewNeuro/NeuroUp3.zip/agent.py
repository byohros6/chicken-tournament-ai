import os
import torch
import numpy as np
import time
from game.enums import Direction, MoveType
from .model import ZeroNet
from .neuro_mcts import NeuroMCTS, decode_move_idx, encode_move_idx
from .belief import TrapdoorBelief

class PlayerAgent:
    def __init__(self, board, time_left):
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.net = ZeroNet().to(self.device)
        self.brain_ready = False
        
        self.belief = TrapdoorBelief()
        
        path = os.path.join(os.path.dirname(__file__), "brain.pth")
        if os.path.exists(path):
            try:
                state = torch.load(path, map_location=self.device, weights_only=False)
                self.net.load_state_dict(state)
                self.net.eval()
                # Warmup the GPU
                dummy = torch.zeros((1, 8, 8, 8), device=self.device)
                self.net(dummy)
                
                self.mcts = NeuroMCTS(self.net)
                self.brain_ready = True
                print("NEURO: Grandmaster Brain Loaded.")
            except Exception as e:
                print(f"NEURO: Load failed! {e}")
        
    def play(self, board, sensor_data, time_left):
        # 1. Update Trap Beliefs from SENSORS
        my_loc = board.chicken_player.get_location()
        self.belief.update(my_loc, sensor_data)
        
        # 2. Update Trap Beliefs from HARD FACTS
        if hasattr(board, 'found_trapdoors'):
            self.belief.set_confirmed_traps(board.found_trapdoors)
        
        valid_moves = board.get_valid_moves()
        if not valid_moves: return (Direction.UP, MoveType.PLAIN)

        if not self.brain_ready:
            return valid_moves[0]
            
        # 3. CONSERVATIVE TIME MANAGEMENT
        turns_remaining = board.turns_left_player
        my_time = time_left()
        
        # Reserve 1 second for safety (never touch this!)
        usable_time = my_time - 1.0
        
        if usable_time <= 0:
            # PANIC MODE: Instant move, no search
            thinking_time = 0.0
            batch_size = 1
        else:
            # Safe Budget: Divide usable time evenly among remaining turns
            # No multiplier, capped at 3.0s to avoid wasting time on simple moves
            base_budget = usable_time / (turns_remaining + 1)
            thinking_time = min(base_budget, 3.0)
            
            # If we have lots of time, batch size 32 is fast.
            # If we have < 0.5s, batch size 1 allows precise stopping.
            batch_size = 32 if thinking_time > 0.5 else 1
            
        start_t = time.time()
        root = self.mcts.search_setup(board, belief_map=self.belief.probs)
        
        # Search until time is up (or if we have 0 time, just use Prior)
        if thinking_time > 0:
            while time.time() - start_t < thinking_time:
                self.mcts.search_batch(root, batch_size=batch_size)
            
        probs = self.mcts.get_probs(root)
        
        # 4. Legal Move Filter
        best_move = valid_moves[0]
        best_prob = -1.0
        
        for d, t in valid_moves:
            idx = encode_move_idx(d, t)
            move_prob = probs[idx]
            
            if move_prob > best_prob:
                best_prob = move_prob
                best_move = (d, t)
        
        return best_move