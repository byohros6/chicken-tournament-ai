import os
import torch
import numpy as np
import time
from game.enums import Direction, MoveType
from .model import ZeroNet
from .neuro_mcts import NeuroMCTS, decode_move_idx
from .belief import TrapdoorBelief

class PlayerAgent:
    def __init__(self, board, time_left):
        # 1. Setup Device
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.net = ZeroNet().to(self.device)
        self.brain_ready = False
        
        # 2. Initialize Belief System (The Eyes)
        self.belief = TrapdoorBelief()
        
        # 3. Load the Grandmaster Brain
        path = os.path.join(os.path.dirname(__file__), "brain.pth")
        if os.path.exists(path):
            try:
                state = torch.load(path, map_location=self.device, weights_only=False)
                self.net.load_state_dict(state)
                self.net.eval()
                # Warmup the GPU
                dummy = torch.zeros((1, 8, 8, 8), device=self.device)
                self.net(dummy)
                
                self.mcts = NeuroMCTS(self.net)
                self.brain_ready = True
                print("NEURO: Grandmaster Brain Loaded.")
            except Exception as e:
                print(f"NEURO: Load failed! {e}")
        
    def play(self, board, sensor_data, time_left):
        # 1. Update Trap Beliefs
        my_loc = board.chicken_player.get_location()
        self.belief.update(my_loc, sensor_data)
        
        # 2. Fallback if brain died
        if not self.brain_ready:
            moves = board.get_valid_moves()
            return moves[0] if moves else (Direction.UP, MoveType.PLAIN)
            
        # 3. DYNAMIC TIME MANAGEMENT
        # We have 6 minutes (360s) total.
        # We want to use ~90% of our remaining time over the expected remaining turns.
        
        turns_remaining = board.turns_left_player
        my_time = time_left()
        
        # Safety buffer (don't flag out)
        if my_time < 1.0:
            thinking_time = 0.05 # Panic mode
        else:
            # Budget: (Time / Turns) * Aggression Factor
            # Early game: Play fast. Mid/Late game: Think deep.
            base_budget = my_time / (turns_remaining + 2)
            thinking_time = min(base_budget * 1.5, 4.0) # Cap at 4s per move
            
        # 4. Run MCTS by TIME, not iterations
        # This lets the 3050Ti run 2,000 sims while a CPU might run 200
        start_t = time.time()
        sims = 0
        
        # Reset search tree for new position
        # (We rebuild tree from scratch to be safe and stateless)
        root = self.mcts.search_setup(board, belief_map=self.belief.probs)
        
        while time.time() - start_t < thinking_time:
            # Run a batch of simulations
            self.mcts.search_batch(root, batch_size=32)
            sims += 32
            
        # 5. Select Best Move
        probs = self.mcts.get_probs(root)
        move_idx = np.argmax(probs)
        
        # Log for debugging
        print(f"Neuro: {sims} sims in {thinking_time:.2f}s (Time left: {my_time:.1f}s)")
        
        return decode_move_idx(move_idx)