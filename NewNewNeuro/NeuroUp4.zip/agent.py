import os
import torch
import numpy as np
import time
import random
from game.enums import Direction, MoveType
from .model import ZeroNet
from .neuro_mcts import NeuroMCTS, decode_move_idx, encode_move_idx
from .belief import TrapdoorBelief

class PlayerAgent:
    def __init__(self, board, time_left):
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.net = ZeroNet().to(self.device)
        self.brain_ready = False
        
        self.belief = TrapdoorBelief()
        
        path = os.path.join(os.path.dirname(__file__), "brain.pth")
        if os.path.exists(path):
            try:
                # weights_only=False required for older pytorch versions/custom classes
                state = torch.load(path, map_location=self.device, weights_only=False)
                self.net.load_state_dict(state)
                self.net.eval()
                # Warmup
                dummy = torch.zeros((1, 8, 8, 8), device=self.device)
                self.net(dummy)
                
                self.mcts = NeuroMCTS(self.net)
                self.brain_ready = True
                print("NEURO: Brain Loaded.")
            except Exception as e:
                print(f"NEURO: Load failed! {e}")
        
    def play(self, board, sensor_data, time_left):
        # --- GLOBAL CRASH PROTECTION ---
        # If anything fails, fall back to random valid move
        try:
            valid_moves = board.get_valid_moves()
            if not valid_moves: return (Direction.UP, MoveType.PLAIN)

            # 1. Update Beliefs
            my_loc = board.chicken_player.get_location()
            self.belief.update(my_loc, sensor_data)
            
            if hasattr(board, 'found_trapdoors'):
                self.belief.set_confirmed_traps(board.found_trapdoors)
            
            # 2. Quick check: If brain dead, play random
            if not self.brain_ready:
                return valid_moves[0]
                
            # 3. STRICT TIME MANAGEMENT
            turns_remaining = board.turns_left_player
            my_time = time_left()
            
            # Reserve 2 seconds for network lag/safety
            usable_time = my_time - 2.0
            
            if usable_time <= 0.5:
                # PANIC MODE: Zero search, just use prior policy
                thinking_time = 0.0
            else:
                # Distribute time, but capped conservatively
                base_budget = usable_time / (turns_remaining + 2)
                thinking_time = min(base_budget, 2.5) # Never think > 2.5s
                
            start_t = time.time()
            
            # Initialize Tree
            # Note: search_setup does one expansion (inference), which takes time!
            root = self.mcts.search_setup(board, belief_map=self.belief.probs)
            
            # 4. Run MCTS (Loop 1 simulation at a time for perfect timing)
            sims = 0
            
            # Only search if we have budget AND the setup didn't already eat it all
            if thinking_time > 0.05:
                while time.time() - start_t < thinking_time:
                    self.mcts.search_batch(root, batch_size=1)
                    sims += 1
                    
                    # Emergency Brake: If 1 sim took > 0.5s (Slow CPU), stop early
                    # This prevents "Death by Slow Server"
                    if sims == 1 and (time.time() - start_t) > 0.5:
                        print("NEURO: Slow hardware detected. Stopping search.")
                        break
            
            probs = self.mcts.get_probs(root)
            
            # 5. Legal Move Filter
            best_move = valid_moves[0]
            best_prob = -1.0
            
            for d, t in valid_moves:
                idx = encode_move_idx(d, t)
                move_prob = probs[idx]
                
                if move_prob > best_prob:
                    best_prob = move_prob
                    best_move = (d, t)
            
            return best_move

        except Exception as e:
            # THE AIRBAG: Catch any crash and play a valid move
            print(f"NEURO CRASHED: {e}")
            valid_moves = board.get_valid_moves()
            if valid_moves:
                return valid_moves[0]
            return (Direction.UP, MoveType.PLAIN)