import os
import torch
import numpy as np
from game.enums import Direction, MoveType
from .model import ZeroNet
from .neuro_mcts import NeuroMCTS, decode_move_idx

class PlayerAgent:
    def __init__(self, board, time_left):
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.net = ZeroNet().to(self.device)
        self.brain_ready = False
        
        # Load Weights
        path = os.path.join(os.path.dirname(__file__), "brain.pth")
        if os.path.exists(path):
            try:
                # Load to GPU if available
                self.net.load_state_dict(torch.load(path, map_location=self.device))
                self.net.eval()
                self.mcts = NeuroMCTS(self.net)
                self.brain_ready = True
            except:
                print("NEURO: Brain load failed.")
        
    def play(self, board, sensor_data, time_left):
        if not self.brain_ready:
            # Fallback to random if no brain found
            moves = board.get_valid_moves()
            return moves[0] if moves else (Direction.UP, MoveType.PLAIN)
            
        # Run MCTS
        # 50 sims is a good balance for tournament play on GPU
        probs = self.mcts.search(board, num_sims=50)
        
        # Pick best move (Argmax)
        move_idx = np.argmax(probs)
        return decode_move_idx(move_idx)