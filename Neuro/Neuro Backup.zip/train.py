import os
import torch
import torch.optim as optim
import numpy as np
import random
import time
import sys
from game.board import Board
from game.game_map import GameMap
from .model import ZeroNet
from .neuro_mcts import NeuroMCTS, decode_move_idx

# --- TUNED FOR RTX 3050Ti ---
ITERATIONS = 1000       
PARALLEL_GAMES = 256    # Reduced from 2048 to stop CPU freeze
MCTS_SIMS = 20          # Good balance
EPOCHS = 1              # Train faster per loop
BATCH_SIZE = 128        

# Cache the map to save CPU cycles
CACHED_MAP = GameMap()

def setup_game_reuse(board):
    """Resets a board in-place instead of creating a new object."""
    # Reset Metadata
    board.turn_count = 0
    board.winner = None
    board.eggs_player.clear()
    board.eggs_enemy.clear()
    board.turds_player.clear()
    board.turds_enemy.clear()
    
    # Random Start
    row = random.randint(1, 6)
    p1_start = (0, row)
    p2_start = (7, row)
    
    # Reset Chickens
    # We assume the board already has chicken objects
    board.chicken_player.start(p1_start, (p1_start[0]+p1_start[1])%2)
    board.chicken_player.eggs_laid = 0
    board.chicken_player.turds_left = 5
    
    board.chicken_enemy.start(p2_start, (p2_start[0]+p2_start[1])%2)
    board.chicken_enemy.eggs_laid = 0
    board.chicken_enemy.turds_left = 5
    
    return board

def init_boards():
    """Create the pool of boards once."""
    print(f"Allocating {PARALLEL_GAMES} game boards...", end='', flush=True)
    boards = []
    for _ in range(PARALLEL_GAMES):
        boards.append(Board(CACHED_MAP))
    print(" Done.")
    return boards

def parallel_self_play(net, board_pool):
    mcts = NeuroMCTS(net)
    
    # 1. Reset all boards in the pool
    for b in board_pool:
        setup_game_reuse(b)
    
    from .neuro_mcts import MCTSNode
    roots = [MCTSNode(b, prior=1.0) for b in board_pool]
    
    # Initial Expansion (Wake up GPU)
    mcts.process_batch(roots)
    
    histories = [[] for _ in range(PARALLEL_GAMES)]
    active_indices = list(range(PARALLEL_GAMES))
    completed_data = []

    print(f"  > Playing...", end='', flush=True)
    last_print = time.time()
    
    while active_indices:
        # Print progress every 3 seconds
        if time.time() - last_print > 3:
            print(f" {len(active_indices)} left...", end='', flush=True)
            last_print = time.time()

        # 1. MCTS Simulations
        for _ in range(MCTS_SIMS):
            leaves = []
            for idx in active_indices:
                leaf = mcts.step_select(roots[idx])
                if leaf.board.is_game_over():
                     diff = leaf.board.chicken_player.get_eggs_laid() - leaf.board.chicken_enemy.get_eggs_laid()
                     val = 1.0 if diff > 0 else (-1.0 if diff < 0 else 0.0)
                     mcts.step_backprop(leaf, val)
                else:
                    leaves.append(leaf)
            if leaves: mcts.process_batch(leaves)

        # 2. Play Move
        finished_indices = []
        for idx in active_indices:
            root = roots[idx]
            
            counts = np.zeros(12)
            for k, v in root.children.items(): counts[k] = v.visits
            s = np.sum(counts)
            probs = counts / s if s > 0 else np.ones(12)/12

            histories[idx].append([mcts.encode(root.board), probs, 0])

            move_idx = np.random.choice(12, p=probs)
            d, t = decode_move_idx(move_idx)
            
            if move_idx in root.children:
                roots[idx] = root.children[move_idx]
                roots[idx].parent = None
                if roots[idx].board is None:
                    roots[idx].board = root.board.forecast_move(d, t, check_ok=False)
                    if not roots[idx].board:
                         finished_indices.append(idx)
                         continue
                    mcts.process_batch([roots[idx]])
            else:
                new_b = root.board.forecast_move(d, t, check_ok=False)
                if not new_b: 
                    finished_indices.append(idx)
                    continue
                roots[idx] = MCTSNode(new_b, prior=1.0)
                mcts.process_batch([roots[idx]])

            if roots[idx].board.is_game_over():
                finished_indices.append(idx)

        # 3. Handle Finished
        for idx in finished_indices:
            active_indices.remove(idx)
            b = roots[idx].board
            p1, p2 = b.chicken_player.get_eggs_laid(), b.chicken_enemy.get_eggs_laid()
            winner = 1.0 if p1 > p2 else (-1.0 if p2 > p1 else 0.0)
            
            h = histories[idx]
            for i in range(len(h)):
                h[i][2] = winner * ((-1) ** (i % 2))
                completed_data.append(h[i])
                
    print(" Done.")
    return completed_data

def train():
    # Speed Settings
    torch.backends.cudnn.benchmark = True
    torch.set_float32_matmul_precision('medium') # 30-series optimization
    
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Training on: {device}")
    if device.type == 'cpu':
        print("WARNING: GPU NOT FOUND. Training will be extremely slow.")
    
    net = ZeroNet().to(device)
    path = os.path.join(os.path.dirname(__file__), "brain.pth")
    
    if os.path.exists(path):
        try:
            net.load_state_dict(torch.load(path, map_location=device))
            print("Loaded Brain.")
        except: pass
            
    optimizer = optim.Adam(net.parameters(), lr=0.002)
    scaler = torch.amp.GradScaler('cuda')
    
    # Pre-allocate boards once to stop CPU churn
    board_pool = init_boards()

    for i in range(ITERATIONS):
        print(f"--- Iteration {i} ---")
        
        start_gen = time.time()
        data = parallel_self_play(net, board_pool)
        gen_time = time.time() - start_gen
        
        print(f"  > Generated {len(data)} samples in {gen_time:.1f}s ({len(data)/gen_time:.0f} samp/s)")
        
        # Faster numpy stack
        states = np.stack([x[0] for x in data])
        probs = np.stack([x[1] for x in data])
        values = np.stack([x[2] for x in data]).reshape(-1, 1)
        
        net.train()
        indices = np.arange(len(states))
        
        for _ in range(EPOCHS):
            np.random.shuffle(indices)
            for j in range(0, len(states), BATCH_SIZE):
                batch_idx = indices[j:j+BATCH_SIZE]
                
                s_t = torch.from_numpy(states[batch_idx]).to(device)
                p_t = torch.from_numpy(probs[batch_idx]).to(device)
                v_t = torch.from_numpy(values[batch_idx]).to(device)
                
                optimizer.zero_grad()
                with torch.amp.autocast('cuda'):
                    pred_log_p, pred_v = net(s_t)
                    loss = -torch.mean(torch.sum(p_t * pred_log_p, 1)) + \
                            torch.nn.functional.mse_loss(pred_v, v_t)
                
                scaler.scale(loss).backward()
                scaler.step(optimizer)
                scaler.update()
        
        torch.save(net.state_dict(), path)
        if i % 5 == 0: torch.cuda.empty_cache()

if __name__ == "__main__":
    train()