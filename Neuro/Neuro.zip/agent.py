import os
import torch
import numpy as np
from typing import List, Tuple, Callable
from game.board import Board
from game.enums import Direction, MoveType

# Relative import for the model structure
from .model import ChickenNet

class PlayerAgent:
    def __init__(self, board: Board, time_left: Callable):
        self.model = ChickenNet()
        
        # Load the trained brain
        # We use __file__ to find the path relative to this script
        weight_path = os.path.join(os.path.dirname(__file__), "brain.pth")
        
        try:
            self.model.load_state_dict(torch.load(weight_path))
            self.model.eval() # Set to Evaluation Mode
            self.brain_active = True
        except Exception as e:
            print(f"NEURO ERROR: Could not load brain! {e}")
            self.brain_active = False

    def play(self, board: Board, sensor_data: List[Tuple[bool, bool]], time_left: Callable):
        # Get all valid moves
        valid_moves = board.get_valid_moves()
        if not valid_moves: return (Direction.UP, MoveType.PLAIN)
        
        best_move = valid_moves[0]
        best_score = float('-inf')
        
        # NEURAL SEARCH
        # For every possible move, ask the brain: "How good is this future?"
        for direction, move_type in valid_moves:
            # Forecast the future board state
            next_board = board.forecast_move(direction, move_type, check_ok=False)
            
            if next_board:
                if self.brain_active:
                    score = self.neural_evaluate(next_board)
                else:
                    # Fallback if brain failed to load: Count Eggs
                    score = next_board.chicken_player.get_eggs_laid()
                
                if score > best_score:
                    best_score = score
                    best_move = (direction, move_type)
                    
        return best_move

    def neural_evaluate(self, board: Board):
        """Encodes the board and gets the Win Probability from the Neural Net."""
        state = self.encode_board(board)
        
        # Pass to PyTorch Model
        with torch.no_grad():
            tensor_in = torch.tensor(state, dtype=torch.float32).unsqueeze(0) # Add batch dimension
            score = self.model(tensor_in).item()
            
        return score

    def encode_board(self, board):
        """Same encoding function as the data miner."""
        state = np.zeros((6, 8, 8), dtype=np.float32)
        
        # We always view the board from our perspective (me vs enemy)
        me = board.chicken_player
        enemy = board.chicken_enemy
        
        mx, my = me.get_location()
        state[0, mx, my] = 1
        
        ex, ey = enemy.get_location()
        state[1, ex, ey] = 1
        
        for (x, y) in board.eggs_player: state[2, x, y] = 1
        for (x, y) in board.eggs_enemy: state[3, x, y] = 1
        for (x, y) in board.turds_player: state[4, x, y] = 1
        for (x, y) in board.turds_enemy: state[5, x, y] = 1
            
        return state