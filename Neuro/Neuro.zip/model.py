import torch
import torch.nn as nn
import torch.nn.functional as F

class ChickenNet(nn.Module):
    def __init__(self):
        super(ChickenNet, self).__init__()
        # Input: 6 channels (MyLoc, EnLoc, MyEggs, EnEggs, MyTurds, EnTurds)
        # Board: 8x8
        # Total Input Size: 6 * 8 * 8 = 384 neurons
        self.fc1 = nn.Linear(384, 512)
        self.fc2 = nn.Linear(512, 256)
        self.fc3 = nn.Linear(256, 128)
        self.out = nn.Linear(128, 1) # Output: Win Probability (-1.0 to 1.0)

    def forward(self, x):
        # Flatten the board
        x = x.view(-1, 384)
        
        # Neural Layers (ReLU activation)
        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))
        x = F.relu(self.fc3(x))
        
        # Tanh squashes output to [-1, 1] range
        return torch.tanh(self.out(x))